# France Top 50 - Audience Sensitivity, Content Compliance & Format Preference

| File | Purpose |
|---|---|
| `Research_Paper_France_Top50.docx` | EDA, insights, KPIs, recommendations, limitations |
| `Executive_Summary_France_Top50.docx` | 1-page plain-language summary for stakeholders |
| `app.py` | Streamlit dashboard (date range, Top 10/25/50, explicit toggle, album type filters) |
| `fr_top50.py` | Data cleaning + KPI definitions shared by app and analysis |
| `run_eda.py` | Reproduces statistics and figures (writes the cleaned CSV) |
| `Atlantic_France.csv` / `Atlantic_France_clean.csv` | Raw / cleaned data |

## Run the dashboard
```
pip install -r requirements.txt
streamlit run app.py
```
Keep `Atlantic_France.csv` in the same folder (or upload it in the sidebar).

## Cleaning rules
Duplicate rows removed; 1 corrupt row (no title/duration) removed; 1 Mar 2025 held two different snapshots (first kept);
popularity 0 treated as missing; 4 calendar days absent in source; durations converted to minutes.
