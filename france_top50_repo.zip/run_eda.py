import pandas as pd, numpy as np, json, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
from fr_top50 import *
OUT="/home/claude/proj/figs"; os.makedirs(OUT,exist_ok=True)
d,log=load_and_clean('/mnt/user-data/uploads/Atlantic_France.csv',True)
d.drop(columns=['month']).to_csv('/mnt/user-data/outputs/france_top50/Atlantic_France_clean.csv',index=False)
C={'Explicit':'#C8102E','Clean':'#1F4E9C','single':'#E08A00','album':'#2A7F62','compilation':'#888'}
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150})
def save(n): plt.tight_layout(); plt.savefig(f"{OUT}/{n}.png"); plt.close()
S={}
# Fig1 explicit by rank band & tier
bands=pd.cut(d.position,[0,5,10,20,30,40,50],labels=['1-5','6-10','11-20','21-30','31-40','41-50'])
eb=d.groupby(bands,observed=True).is_explicit.mean()*100
fig,ax=plt.subplots(1,2,figsize=(9,3.4),gridspec_kw={'width_ratios':[1.6,1]})
ax[0].bar(eb.index.astype(str),eb.values,color=C['Explicit']);ax[0].axhline(d.is_explicit.mean()*100,ls='--',c='k',lw=1);ax[0].set_ylim(0,75)
for i,v in enumerate(eb.values):ax[0].text(i,v+1,f"{v:.0f}%",ha='center')
ax[0].set_title('Explicit share by rank band (dashed = overall)');ax[0].set_ylabel('% of chart slots')
t=[tier(d,n).is_explicit.mean()*100 for n in (10,25,50)]
ax[1].bar(['Top 10','Top 25','Top 50'],t,color=C['Explicit'],alpha=.8);ax[1].set_ylim(0,75);ax[1].set_title('Explicit share by tier')
for i,v in enumerate(t):ax[1].text(i,v+1,f"{v:.1f}%",ha='center')
save('fig1_explicit_rank'); S['explicit_band']=eb.round(1).to_dict(); S['explicit_tier']=dict(zip(['Top10','Top25','Top50'],np.round(t,1)))
# Fig2 popularity box + monthly trend
fig,ax=plt.subplots(1,2,figsize=(9,3.4),gridspec_kw={'width_ratios':[1,1.7]})
bp=ax[0].boxplot([d[~d.is_explicit].popularity.dropna(),d[d.is_explicit].popularity.dropna()],labels=['Clean','Explicit'],patch_artist=True,showfliers=False)
for p,c in zip(bp['boxes'],[C['Clean'],C['Explicit']]):p.set_facecolor(c);p.set_alpha(.7)
ax[0].set_title('Popularity score');
m=d.groupby('month').is_explicit.mean()*100;ax[1].plot(m.index,m.values,marker='o',c=C['Explicit']);ax[1].axhline(50,c='grey',lw=.8,ls=':')
ax[1].set_title('Monthly explicit share (%)');ax[1].set_ylim(35,75);fig.autofmt_xdate()
save('fig2_explicit_pop_trend')
pc=d.groupby('content').popularity.mean();mw=stats.mannwhitneyu(d[d.is_explicit].popularity.dropna(),d[~d.is_explicit].popularity.dropna())
S['pop_content']=pc.round(2).to_dict();S['mw_p']=float(mw.pvalue)
S['monthly_explicit']={str(k.date())[:7]:round(v,1) for k,v in m.items()}
t=d.groupby('track_id').agg(days=('date','nunique'),exp=('is_explicit','max'),typ=('album_type','first'))
S['longevity']=t.groupby('exp').days.agg(['mean','median','count']).round(1).to_dict('index')
S['longevity_type']=t.groupby('typ').days.agg(['mean','median','count']).round(1).to_dict('index')
# Fig3 format
fig,ax=plt.subplots(1,3,figsize=(10,3.3))
sh=d[d.album_type!='compilation'].groupby(['position']).album_type.value_counts(normalize=True).unstack().fillna(0)
tiers=pd.DataFrame({f'Top {n}':tier(d,n).album_type.value_counts(normalize=True) for n in (10,25,50)}).T.fillna(0)[['single','album','compilation']]*100
tiers[['single','album']].plot.bar(stacked=True,ax=ax[0],color=[C['single'],C['album']],rot=0,legend=False)
for i,(s,a) in enumerate(zip(tiers.single,tiers.album)):ax[0].text(i,s/2,f"{s:.0f}%",ha='center',color='w');ax[0].text(i,s+a/2,f"{a:.0f}%",ha='center',color='w')
ax[0].set_title('Format mix by tier');ax[0].legend(['Single','Album'],fontsize=8,loc='lower right')
b=d.groupby(bands,observed=True).album_type.apply(lambda s:(s=='single').mean()*100);ax[1].plot(b.index.astype(str),b.values,marker='o',c=C['single']);ax[1].set_ylim(30,60);ax[1].set_title('Single share by rank band (%)')
pt=d[d.album_type!='compilation'].groupby('album_type').popularity.mean();ax[2].bar(pt.index,pt.values,color=[C['album'],C['single']]);ax[2].set_ylim(60,85);ax[2].set_title('Mean popularity')
for i,v in enumerate(pt.values):ax[2].text(i,v+.4,f"{v:.1f}",ha='center')
save('fig3_format');S['tiers']=tiers.round(1).to_dict('index');S['pop_type']=pt.round(2).to_dict()
S['pos_type']=d.groupby('album_type').position.mean().round(2).to_dict()
# Fig4 album size
fig,ax=plt.subplots(1,3,figsize=(10.5,3.4))
ua=d.drop_duplicates('album_cover_url');ax[0].hist(ua.total_tracks.clip(upper=40),bins=range(1,42),color='#555');ax[0].set_title('Album size (unique releases, capped at 40)');ax[0].set_xlabel('total_tracks')
sb=d.groupby('size_band',observed=True).popularity.mean();ax[1].bar(range(len(sb)),sb.values,color='#2A7F62');ax[1].set_xticks(range(len(sb)));ax[1].set_xticklabels([s.split(' ')[0]+'\n'+s.split(' ')[1] for s in sb.index],fontsize=8);ax[1].set_ylim(60,85);ax[1].set_title('Mean popularity by album size')
a=d[d.album_type=='album']
for e,l in [(False,'Clean'),(True,'Explicit')]:
    x=a[a.is_explicit==e].groupby('size_band',observed=True).popularity.mean().dropna();ax[2].plot([s.split(' ')[0] for s in x.index],x.values,marker='o',c=C[l],label=l)
ax[2].legend(fontsize=8);ax[2].set_title('Albums only: size effect, split by content');ax[2].set_ylim(65,85)
save('fig4_album_size')
S['size_band']=d.groupby('size_band',observed=True).agg(n=('song','size'),pop=('popularity','mean'),pos=('position','mean'),exp=('is_explicit','mean')).round(3).to_dict('index')
S['rho_size_pop_albums']=float(stats.spearmanr(a.total_tracks,a.popularity,nan_policy='omit')[0])
S['rho_by_content']={l:round(float(stats.spearmanr(a[a.is_explicit==e].total_tracks,a[a.is_explicit==e].popularity,nan_policy='omit')[0]),3) for e,l in [(False,'Clean'),(True,'Explicit')]}
g=a.groupby(['date','album_cover_url']).agg(k=('song','size'),pop=('popularity','mean'),pos=('position','mean')).reset_index()
gg=g.groupby(pd.cut(g.k,[0,1,2,4,100],labels=['1','2','3-4','5+'])).agg(n=('k','size'),pop=('pop','mean'),pos=('pos','mean')).round(2);S['flood']=gg.to_dict('index')
# Fig5 duration
fig,ax=plt.subplots(1,3,figsize=(10.5,3.4))
ax[0].hist(d.duration_min.clip(upper=6),bins=60,color='#444');ax[0].axvline(d.duration_min.mean(),c=C['Explicit'],ls='--');ax[0].set_title('Duration distribution (min)')
db=d.groupby('duration_bucket',observed=True).agg(n=('song','size'),pop=('popularity','mean'),pos=('position','mean'),exp=('is_explicit','mean'));
ax[1].bar(['Short','Medium','Long'],db['n']/len(d)*100,color='#555');ax[1].set_title('Share of slots by bucket (%)')
for i,v in enumerate(db['n']/len(d)*100):ax[1].text(i,v+.7,f"{v:.0f}%",ha='center')
ax[2].bar(['Short','Medium','Long'],db['pop'],color=['#8aa','#58a','#235']);ax[2].set_ylim(70,82);ax[2].set_title('Mean popularity by bucket')
save('fig5_duration');S['dur']=db.round(3).to_dict('index')
S['dur_stats']=d.duration_min.describe().round(3).to_dict()
S['rho_dur_pop']=float(stats.spearmanr(d.duration_min,d.popularity,nan_policy='omit')[0]);S['rho_dur_pos']=float(stats.spearmanr(d.duration_min,d.position)[0])
S['rho_pos_pop']=float(stats.spearmanr(d.position,d.popularity,nan_policy='omit')[0])
# Fig6 attribute density + acceptance
d['single']=d.album_type=='single'; d['long']=d.duration_bucket.astype(str).str.startswith('Long'); d['short']=d.duration_bucket.astype(str).str.startswith('Short');d['large_album']=d.total_tracks>=13
attrs={'Explicit':'is_explicit','Single':'single','Large album (13+)':'large_album','Long (>3.5m)':'long','Short (<2.5m)':'short'}
dens=pd.DataFrame({f'Top {n}':{k:tier(d,n)[v].mean()*100 for k,v in attrs.items()} for n in (10,25,50)})
fig,ax=plt.subplots(1,2,figsize=(10,3.4),gridspec_kw={'width_ratios':[1.2,1]})
im=ax[0].imshow(dens.values,cmap='Blues',aspect='auto',vmin=0,vmax=80);ax[0].set_xticks(range(3));ax[0].set_xticklabels(dens.columns);ax[0].set_yticks(range(len(dens)));ax[0].set_yticklabels(dens.index)
for i in range(dens.shape[0]):
    for j in range(3):ax[0].text(j,i,f"{dens.values[i,j]:.0f}%",ha='center',va='center',color='w' if dens.values[i,j]>45 else 'k')
ax[0].set_title('Attribute density by tier');[ax[0].spines[s].set_visible(False) for s in ax[0].spines]
cas={}
for c in ['content','album_type','duration_bucket','size_band']:
    for k,v in acceptance_score(d,c).items():cas[str(k)]=round(float(v),1)
cas.pop('compilation',None);cas={{'single':'Format: Single','album':'Format: Album','Single (1)':'Size: 1 track','Clean':'Clean','Explicit':'Explicit'}.get(k,k):v for k,v in cas.items()}
ks=sorted(cas,key=cas.get);ax[1].barh(ks,[cas[k] for k in ks],color=['#C8102E' if cas[k]<100 else '#2A7F62' for k in ks]);ax[1].axvline(100,c='k',lw=1);ax[1].set_xlim(80,112);ax[1].set_title('Acceptance Score (100 = neutral)',fontsize=10);ax[1].tick_params(axis='y',labelsize=8)
save('fig6_density_cas');S['density']=dens.round(1).to_dict();S['cas']=cas
# profiles
d['profile']=d.content+' / '+np.where(d.single,'Single','Album')+' / '+d.duration_bucket.astype(str).str.split(' ').str[0]
S['profiles']={f'Top{n}':(tier(d,n).profile.value_counts(normalize=True).head(5)*100).round(1).to_dict() for n in (10,25,50)}
S['kpis']={k:round(float(v),3) for k,v in kpis(d).items()};S['kpis_tier']={f'Top{n}':{k:round(float(v),3) for k,v in kpis(tier(d,n)).items()} for n in (10,25)}
S['content_pos']=d.groupby('content').position.mean().round(2).to_dict()
S['explicit_by_type']=(d.groupby('album_type').is_explicit.mean()*100).round(1).to_dict()
S['top_artist_share']=(d.artist.value_counts(normalize=True).head(5)*100).round(1).to_dict()
S['log']=log;S['n_unique_tracks']=log['unique_tracks']
json.dump(S,open('stats.json','w'),indent=1,default=str);print(json.dumps(S['kpis'],indent=1));print(S['longevity'],S['longevity_type'],S['flood'],S['rho_by_content'])
